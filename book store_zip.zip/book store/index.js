const dotenv = require('dotenv');
const express = require('express');
const mongoose = require('mongoose');

dotenv.config();

const app = express();

    app.use(express.json());

const PORT = process.env.PORT || 2000;
const MONGOURL = process.env.MONGO_URL;

mongoose.connect(MONGOURL).then(() => {
  console.log("Connected to MongoDB successfully...");
  app.listen(PORT, () => {
    console.log("Server running successfully on port: " + PORT);
  });
}).catch((err) => {
  console.error("Failed to connect to MongoDB:", err);
});

const userSchema = new mongoose.Schema({
  _id:Number,
  name: String,
  author: String,
  pages: Number,
  price: Number,
  publisher: String
});

const userModel = mongoose.model("books", userSchema);

app.get("/", (req, res) => {
  res.send("<h1>This is Home Page</h1>");
});

app.get("/getBooks", async (req, res) => {
  try {
    const userData = await userModel.find();
    res.send(userData);
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

app.get("/getBooks/:id", async (req, res) => {
    const ids = parseInt(req.params.id);
    try {
      const data = await userModel.findOne({ _id: ids });
      if (!data) {
        res.json({ error: 'Book not found' });
      }else{
          res.json(data);
      }
    } catch (error) {
      console.error(error);
      res.json({ error: 'Internal server error' });
    }
  });


app.post('/Addbooks', async(req, res) => {
    const data = req.body;
    const newBook = new userModel(data)
    await newBook.save()
    res.send("book added successfully");
})

app.put('/updatebooks/:id',async(req,res)=>{
    const id = req.params.id;
    const updateBook = await userModel.findByIdAndUpdate(id,req.body,{new:true})
    if(!updateBook){
        res.send(`book with id ${id} not found`)
    }else{
        const update = await userModel.findById(id);
        res.send("updated Successfully");
    }
})

app.delete('/removeBook/:id', async (req, res) => {
    const id = req.params.id;
    const deleteBook = await userModel.findByIdAndDelete({ _id: id });
    if(!deleteBook){
        res.send(`book with id ${id} not found`)
    }else{
        res.send("deleted successfully");
    }
});
